package com.github.vipulasri.timelineview.sample.model

/**
 * Created by Vipul Asri on 07-06-2016.
 */

enum class OrderStatus {
    COMPLETED,
    ACTIVE,
    INACTIVE
}
